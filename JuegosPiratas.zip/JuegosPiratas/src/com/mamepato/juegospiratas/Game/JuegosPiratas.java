package com.mamepato.juegospiratas.Game;

import com.mamepato.juegospiratas.framework.implementation.AndroidGame;

public class JuegosPiratas extends AndroidGame
{

}
