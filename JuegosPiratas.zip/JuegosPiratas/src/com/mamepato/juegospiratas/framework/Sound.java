package com.mamepato.juegospiratas.framework;

public interface Sound {
	public void play(float volume);
	public void dispose();
}
