package com.mamepato.juegospiratas.framework;

public interface Audio
{
	public Music nuevaMusica(String nombreArchivo);

	public Sound newSound(String nombreArchivo);
}
