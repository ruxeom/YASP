package helpers;

public enum Types
{
	A, 
	B,
	C,
	D,
	E
}
