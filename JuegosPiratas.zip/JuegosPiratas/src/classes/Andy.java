package classes;

import android.graphics.Color;

public class Andy
{
	int x;
	int y;
	Color color;

	public Andy(int x, int y, Color color)
	{
		this.x = x;
		this.y = y;
		this.color = color;
	}
}
