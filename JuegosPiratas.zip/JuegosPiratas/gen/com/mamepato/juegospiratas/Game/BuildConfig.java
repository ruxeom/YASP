/** Automatically generated file. DO NOT MODIFY */
package com.mamepato.juegospiratas.Game;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}